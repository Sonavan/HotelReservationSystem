package com.example.demo.service;

/* 
 * import java.util.List;

import com.example.demo.entity.BookRoomEntity;
import com.example.demo.entity.Feedback;

public interface FeedbackService {

	//add to Feedback
	public Feedback addFeedback(Feedback feedback);
	
	//get All Feedback
	public List<Feedback> getAllFeedbackByEmail(String email);
	
	//getFeedbackById
	public Feedback getFeedbackById(long id);
	
	
	//get all Feedback
	public List<Feedback> getAllFeedback();
	
	//delete fedback
	public void deleteFeedback(long id);

		
}
*/

import java.util.List;

import com.example.demo.entity.Feedback;

public interface FeedbackService {

	//add to Favorite
	public Feedback addFeedback(Feedback feedback);
	
	//get All Favorite
	public List<Feedback> getAllFeedbackByEmail(String email);
	
	//getFavoriteById
	public Feedback getFeedbackById(long id);
	
	//delete Favorite
	public void deleteFeedbackById(long id);

	List<Feedback> getFeedback();
}


