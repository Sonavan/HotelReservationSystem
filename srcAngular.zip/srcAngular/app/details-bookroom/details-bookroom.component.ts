import { Component } from '@angular/core';

@Component({
  selector: 'app-details-bookroom',
  templateUrl: './details-bookroom.component.html',
  styleUrls: ['./details-bookroom.component.css']
})
export class DetailsBookroomComponent {

}
