import { Component } from '@angular/core';

@Component({
  selector: 'app-create-userinfo',
  templateUrl: './create-userinfo.component.html',
  styleUrls: ['./create-userinfo.component.css']
})
export class CreateUserinfoComponent {

}
