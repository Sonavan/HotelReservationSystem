export class Bookroom {
    userEmail!:string;
    roomId!:number;
    cost!:number;
    paymentMethod!:string;
    debitCardNumber!:number;
    cvv!:number;
    bankName!:string;
    bankAccountHolderName!:string;
    accountNumber!:number;
}
