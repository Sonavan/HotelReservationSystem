import { Bookroom } from './bookroom';

describe('Bookroom', () => {
  it('should create an instance', () => {
    expect(new Bookroom()).toBeTruthy();
  });
});
