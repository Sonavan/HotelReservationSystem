export class Userinfo {
    userId!:number;
    userImgUrl!:string;
    userFirstName!:string;
    userLastName!:string;
    userEmail!:string;
    userAge!:number;
    userPassword!:string;
    userContactNumber!:number;
    userGender!:string;
    userCountry!:string;
    userState!:string;
    userAddress!:string;
    userDistrict!:string;
    userPincode!:number;
}
