export class Feedback {
    userEmail!:string;
    roomId!:number;
    feedbackId!:number;
    comments!:string;
    serviceRating!:string;
}
